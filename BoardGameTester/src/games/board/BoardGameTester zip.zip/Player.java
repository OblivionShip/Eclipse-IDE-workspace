package games.board;
public enum Player {FIRST, SECOND}