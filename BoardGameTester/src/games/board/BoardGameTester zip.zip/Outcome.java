package games.board;
public enum Outcome {PLAYER1_WIN, PLAYER2_WIN, CONTINUE, TIE}